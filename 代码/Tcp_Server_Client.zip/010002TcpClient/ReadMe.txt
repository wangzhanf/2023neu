名称:Tcp 客户端
描述:
前置知识:
后续综合的项目:
主要知识点:客户端使用QTcpSocket
步骤:
    1. 布局一个界面
        注意加载  network模块
        引入 QTcpSocket 头文件

